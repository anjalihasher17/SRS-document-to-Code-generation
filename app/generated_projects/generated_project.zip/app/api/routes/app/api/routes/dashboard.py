from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.database import SessionLocal
from app.models import DashboardTile

router = APIRouter()

class DashboardTileResponse(BaseModel):
    id: str
    title: str
    content: str

@router.get("/api/dashboard/tiles")
async def get_tiles(db: SessionLocal = Depends(get_db)):
    tiles = db.query(DashboardTile).all()
    return [{"id": tile.id, "title": tile.title, "content": tile.content} for tile in tiles]

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()