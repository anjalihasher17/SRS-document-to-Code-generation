from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.database import SessionLocal
from app.models import Pod, PodAssignment

router = APIRouter()

class PodResponse(BaseModel):
    pod_id: str
    pod_name: str
    members: list

@router.get("/api/pods/{pod_id}/details")
async def get_pod_details(pod_id: str, db: SessionLocal = Depends(get_db)):
    pod = db.query(Pod).filter(Pod.id == pod_id).first()
    if not pod:
        raise HTTPException(status_code=404, detail="Pod not found")
    members = db.query(PodAssignment).filter(PodAssignment.pod_id == pod_id).all()
    return {"pod_id": pod.id, "pod_name": pod.name, "members": [{"id": member.user_id, "name": member.user.name, "role": member.role} for member in members]}

@router.post("/api/pods/{pod_id}/recommend")
async def recommend_pod_member(pod_id: str, recommended_user_id: str, db: SessionLocal = Depends(get_db)):
    # implement pod member recommendation logic here
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()