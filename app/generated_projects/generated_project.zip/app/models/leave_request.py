from app.services.database import Base
from sqlalchemy import Column, Integer, Date, Text, Enum, ForeignKey, Index
from sqlalchemy.orm import relationship

class LeaveRequest(Base):
    """
    Represents a leave request.
    """
    __tablename__ = "leave_requests"

    id: int = Column(Integer, primary_key=True)
    """
    Unique identifier for the leave request.
    """

    user_id: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    """
    Foreign key referencing the user who made the leave request.
    """

    start_date: date = Column(Date, nullable=False)
    """
    Start date of the leave.
    """

    end_date: date = Column(Date, nullable=False)
    """
    End date of the leave.
    """

    reason: str = Column(Text, nullable=False)
    """
    Reason for the leave.
    """

    status: str = Column(Enum("pending", "approved", "rejected", name="leave_request_status"), nullable=False)
    """
    Status of the leave request (pending, approved, or rejected).
    """

    created_at: datetime = Column(DateTime, server_default=text("current_timestamp"))
    """
    Timestamp when the leave request was created.
    """

    user = relationship("User", back_populates="leave_requests")
    leave_approvals = relationship("LeaveApproval", back_populates="leave_request")

    __table_args__ = (Index("ix_leave_requests_user_id", "user_id"),)