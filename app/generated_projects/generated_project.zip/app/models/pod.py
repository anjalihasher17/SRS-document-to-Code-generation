from app.services.database import Base
from sqlalchemy import Column, Integer, String, Text
from sqlalchemy.orm import relationship

class Pod(Base):
    """
    Represents a pod.
    """
    __tablename__ = "pods"

    id: int = Column(Integer, primary_key=True)
    """
    Unique identifier for the pod.
    """

    name: str = Column(String(255), nullable=False)
    """
    Name of the pod.
    """

    description: str = Column(Text)
    """
    Description of the pod.
    """

    pod_assignments = relationship("PodAssignment", back_populates="pod")
    pod_recommendations = relationship("PodRecommendation", back_populates="pod")