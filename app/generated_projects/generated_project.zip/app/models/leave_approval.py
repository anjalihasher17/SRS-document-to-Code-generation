from app.services.database import Base
from sqlalchemy import Column, Integer, ForeignKey, Enum, Text, Index
from sqlalchemy.orm import relationship

class LeaveApproval(Base):
    """
    Represents a leave approval.
    """
    __tablename__ = "leave_approvals"

    id: int = Column(Integer, primary_key=True)
    """
    Unique identifier for the leave approval.
    """

    leave_request_id: int = Column(Integer, ForeignKey("leave_requests.id"), nullable=False)
    """
    Foreign key referencing the leave request.
    """

    approved_by: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    """
    Foreign key referencing the user who approved the leave.
    """

    approval_status: str = Column(Enum("approved", "rejected", name="leave_approval_status"), nullable=False)
    """
    Status of the leave approval (approved or rejected).
    """

    comments: str = Column(Text)
    """
    Comments left by the approver.
    """

    leave_request = relationship("LeaveRequest", back_populates="leave_approvals")
    approver = relationship("User", foreign_keys=[approved_by])