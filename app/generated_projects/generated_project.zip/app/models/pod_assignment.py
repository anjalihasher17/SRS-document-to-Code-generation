from app.services.database import Base
from sqlalchemy import Column, Integer, ForeignKey, String, Index
from sqlalchemy.orm import relationship

class PodAssignment(Base):
    """
    Represents a user's assignment to a pod.
    """
    __tablename__ = "pod_assignments"

    id: int = Column(Integer, primary_key=True)
    """
    Unique identifier for the pod assignment.
    """

    pod_id: int = Column(Integer, ForeignKey("pods.id"), nullable=False)
    """
    Foreign key referencing the pod.
    """

    user_id: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    """
    Foreign key referencing the user.
    """

    role: str = Column(String(50), nullable=False)
    """
    Role of the user in the pod.
    """

    pod = relationship("Pod", back_populates="pod_assignments")
    user = relationship("User", back_populates="pod_assignments")

    __table_args__ = (Index("ix_pod_assignments_pod_id", "pod_id"), Index("ix_pod_assignments_user_id", "user_id"))