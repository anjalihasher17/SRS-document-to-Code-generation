from app.services.database import Base
from sqlalchemy import Column, Integer, String, Enum, Index
from sqlalchemy.orm import relationship

class User(Base):
    """
    Represents a user in the system.
    """
    __tablename__ = "users"

    id: int = Column(Integer, primary_key=True)
    """
    Unique identifier for the user.
    """

    email: str = Column(String(255), unique=True, nullable=False)
    """
    Email address of the user.
    """

    password: str = Column(String(255), nullable=False)
    """
    Password for the user.
    """

    name: str = Column(String(255), nullable=False)
    """
    Name of the user.
    """

    role: str = Column(Enum("employee", "manager", name="user_role"), nullable=False)
    """
    Role of the user (employee or manager).
    """

    leave_requests = relationship("LeaveRequest", back_populates="user")
    pod_assignments = relationship("PodAssignment", back_populates="user")

    __table_args__ = (Index("ix_users_email", "email"),)