from app.services.database import Base
from sqlalchemy import Column, Integer, Enum, ForeignKey, Index
from sqlalchemy.orm import relationship

class LeaveBalance(Base):
    """
    Represents a leave balance for a user.
    """
    __tablename__ = "leave_balances"

    id: int = Column(Integer, primary_key=True)
    """
    Unique identifier for the leave balance.
    """

    user_id: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    """
    Foreign key referencing the user who owns the leave balance.
    """

    leave_type: str = Column(Enum("paid_leave", "sick_leave", name="leave_type"), nullable=False)
    """
    Type of leave (paid leave or sick leave).
    """

    balance: int = Column(Integer, nullable=False)
    """
    Current balance of the leave type.
    """

    user = relationship("User", back_populates="leave_balances")

    __table_args__ = (Index("ix_leave_balances_user_id", "user_id"),)