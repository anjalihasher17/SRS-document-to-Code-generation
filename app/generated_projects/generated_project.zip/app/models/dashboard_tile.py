from app.services.database import Base
from sqlalchemy import Column, Integer, String, Text, Enum

class DashboardTile(Base):
    """
    Represents a dashboard tile.
    """
    __tablename__ = "dashboard_tiles"

    id: int = Column(Integer, primary_key=True)
    """
    Unique identifier for the dashboard tile.
    """

    title: str = Column(String(255), nullable=False)
    """
    Title of the dashboard tile.
    """

    content: str = Column(Text, nullable=False)
    """
    Content of the dashboard tile.
    """

    type: str = Column(Enum("leave_summary", "pod_members", name="dashboard_tile_type"), nullable=False)
    """
    Type of the dashboard tile (leave summary or pod members).
    """