from app.services.database import Base
from sqlalchemy import Column, Integer, ForeignKey, DateTime, Index
from sqlalchemy.orm import relationship

class PodRecommendation(Base):
    """
    Represents a pod recommendation.
    """
    __tablename__ = "pod_recommendations"

    id: int = Column(Integer, primary_key=True)
    """
    Unique identifier for the pod recommendation.
    """

    pod_id: int = Column(Integer, ForeignKey("pods.id"), nullable=False)
    """
    Foreign key referencing the pod.
    """

    recommended_user_id: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    """
    Foreign key referencing the recommended user.
    """

    created_at: datetime = Column(DateTime, server_default=text("current_timestamp"))
    """
    Timestamp when the recommendation was created.
    """

    pod = relationship("Pod", back_populates="pod_recommendations")
    recommended_user = relationship("User", foreign_keys=[recommended_user_id])