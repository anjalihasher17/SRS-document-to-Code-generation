
import os
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Create FastAPI app
app = FastAPI(
    title="FastAPI Application",
    description="Generated FastAPI application",
    version="1.0.0",
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Import routers
# from app.api.routes import your_router

# Register routers
# app.include_router(your_router.router, prefix="/api", tags=["Your Tag"])

# Startup event
@app.on_event("startup")
async def startup_event():
    # Initialize database connection
    from app.services.database import init_db
    await init_db()

# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    # Close database connection
    from app.services.database import close_db
    await close_db()

# Root endpoint
@app.get("/", tags=["Root"])
async def root():
    return {
        "message": "Welcome to the FastAPI Application",
        "docs": "/docs",
        "version": app.version,
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
