
# API Documentation

## Endpoints

{
  "endpoints": [
    {
      "http_method": "GET",
      "route_path": "/api/dashboard/tiles",
      "request_parameters": [],
      "response_structure": {
        "tiles": [
          {
            "id": "string",
            "title": "string",
            "content": "string"
          }
        ]
      },
      "status_codes": [
        200
      ],
      "authentication_requirements": {
        "required": true,
        "type": "Bearer token"
      }
    },
    {
      "http_method": "POST",
      "route_path": "/api/lms/leaves/apply",
      "request_parameters": [],
      "request_body": {
        "start_date": "string",
        "end_date": "string",
        "reason": "string"
      },
      "response_structure": {
        "message": "string",
        "status": "string"
      },
      "status_codes": [
        201
      ],
      "authentication_requirements": {
        "required": true,
        "type": "Bearer token"
      }
    },
    {
      "http_method": "PATCH",
      "route_path": "/api/lms/leaves/{leave_id}/approve",
      "request_parameters": [
        {
          "name": "leave_id",
          "type": "string"
        }
      ],
      "request_body": {
        "status": "string"
      },
      "response_structure": {
        "message": "string",
        "status": "string"
      },
      "status_codes": [
        200
      ],
      "authentication_requirements": {
        "required": true,
        "type": "Bearer token",
        "roles": [
          "manager"
        ]
      }
    },
    {
      "http_method": "GET",
      "route_path": "/api/pods/{pod_id}/details",
      "request_parameters": [
        {
          "name": "pod_id",
          "type": "string"
        }
      ],
      "response_structure": {
        "pod_id": "string",
        "pod_name": "string",
        "members": [
          {
            "id": "string",
            "name": "string",
            "role": "string"
          }
        ]
      },
      "status_codes": [
        200
      ],
      "authentication_requirements": {
        "required": true,
        "type": "Bearer token"
      }
    },
    {
      "http_method": "POST",
      "route_path": "/api/pods/{pod_id}/recommend",
      "request_parameters": [
        {
          "name": "pod_id",
          "type": "string"
        }
      ],
      "request_body": {
        "recommended_user_id": "string"
      },
      "response_structure": {
        "message": "string"
      },
      "status_codes": [
        201
      ],
      "authentication_requirements": {
        "required": true,
        "type": "Bearer token"
      }
    },
    {
      "http_method": "POST",
      "route_path": "/api/auth/login",
      "request_parameters": [],
      "request_body": {
        "email": "string",
        "password": "string"
      },
      "response_structure": {
        "token": "string",
        "user": {
          "id": "string",
          "role": "string"
        }
      },
      "status_codes": [
        200
      ],
      "authentication_requirements": {
        "required": false
      }
    },
    {
      "http_method": "GET",
      "route_path": "/api/auth/user",
      "request_parameters": [],
      "response_structure": {
        "id": "string",
        "name": "string",
        "role": "string"
      },
      "status_codes": [
        200
      ],
      "authentication_requirements": {
        "required": true,
        "type": "Bearer token"
      }
    }
  ]
}

## Authentication

{
  "authentication_methods": [
    {
      "method": "JWT (JSON Web Tokens)",
      "description": "Used for authentication, token obtained through login endpoint"
    }
  ],
  "user_roles_and_permissions": [
    {
      "role": "General User (Employee)",
      "permissions": [
        "Submit leave requests",
        "View granted and pending leave requests",
        "Track available leave balances",
        "View assigned pod",
        "Recommend colleagues for inclusion"
      ]
    },
    {
      "role": "Manager",
      "permissions": [
        "Approve or reject leave requests",
        "Access reports of team leave history",
        "Assign employees to specific pods"
      ]
    }
  ],
  "access_control_requirements": [
    {
      "description": "Role-Based Access Control (RBAC) implementation",
      "requirement": "Ensure RBAC, Manager can access both manager and employee related APIs, while user can only access user-specific APIs"
    },
    {
      "description": "Authorization header with Bearer token required for API access",
      "requirement": "Headers: { Authorization: Bearer <token> }"
    }
  ],
  "security_constraints": [
    {
      "constraint": "End-to-end encryption",
      "description": "Data encryption for secure communication"
    },
    {
      "constraint": "API rate-limiting",
      "description": "Prevent abuse and ensure fair usage"
    },
    {
      "constraint": "Data validation",
      "description": "Validate user input and API requests"
    },
    {
      "constraint": "Secure password storage",
      "description": "Not explicitly mentioned, but implied through secure password usage"
    }
  ]
}

## Database Schema

{
  "tables": [
    {
      "table_name": "users",
      "fields": [
        {
          "name": "id",
          "data_type": "integer",
          "primary_key": true
        },
        {
          "name": "email",
          "data_type": "varchar(255)",
          "unique": true
        },
        {
          "name": "password",
          "data_type": "varchar(255)"
        },
        {
          "name": "name",
          "data_type": "varchar(255)"
        },
        {
          "name": "role",
          "data_type": "varchar(50)",
          "enum_values": [
            "employee",
            "manager"
          ]
        }
      ],
      "relationships": [
        {
          "table": "leave_requests",
          "foreign_key": "user_id"
        },
        {
          "table": "pod_assignments",
          "foreign_key": "user_id"
        }
      ]
    },
    {
      "table_name": "leave_requests",
      "fields": [
        {
          "name": "id",
          "data_type": "integer",
          "primary_key": true
        },
        {
          "name": "user_id",
          "data_type": "integer",
          "foreign_key": "users.id"
        },
        {
          "name": "start_date",
          "data_type": "date"
        },
        {
          "name": "end_date",
          "data_type": "date"
        },
        {
          "name": "reason",
          "data_type": "text"
        },
        {
          "name": "status",
          "data_type": "varchar(50)",
          "enum_values": [
            "pending",
            "approved",
            "rejected"
          ]
        },
        {
          "name": "created_at",
          "data_type": "timestamp",
          "default": "current_timestamp"
        }
      ],
      "relationships": [
        {
          "table": "users",
          "foreign_key": "user_id"
        }
      ]
    },
    {
      "table_name": "leave_balances",
      "fields": [
        {
          "name": "id",
          "data_type": "integer",
          "primary_key": true
        },
        {
          "name": "user_id",
          "data_type": "integer",
          "foreign_key": "users.id"
        },
        {
          "name": "leave_type",
          "data_type": "varchar(50)",
          "enum_values": [
            "paid_leave",
            "sick_leave"
          ]
        },
        {
          "name": "balance",
          "data_type": "integer"
        }
      ],
      "relationships": [
        {
          "table": "users",
          "foreign_key": "user_id"
        }
      ]
    },
    {
      "table_name": "pods",
      "fields": [
        {
          "name": "id",
          "data_type": "integer",
          "primary_key": true
        },
        {
          "name": "name",
          "data_type": "varchar(255)"
        },
        {
          "name": "description",
          "data_type": "text"
        }
      ],
      "relationships": [
        {
          "table": "pod_assignments",
          "foreign_key": "pod_id"
        }
      ]
    },
    {
      "table_name": "pod_assignments",
      "fields": [
        {
          "name": "id",
          "data_type": "integer",
          "primary_key": true
        },
        {
          "name": "pod_id",
          "data_type": "integer",
          "foreign_key": "pods.id"
        },
        {
          "name": "user_id",
          "data_type": "integer",
          "foreign_key": "users.id"
        },
        {
          "name": "role",
          "data_type": "varchar(50)"
        }
      ],
      "relationships": [
        {
          "table": "pods",
          "foreign_key": "pod_id"
        },
        {
          "table": "users",
          "foreign_key": "user_id"
        }
      ]
    },
    {
      "table_name": "pod_recommendations",
      "fields": [
        {
          "name": "id",
          "data_type": "integer",
          "primary_key": true
        },
        {
          "name": "pod_id",
          "data_type": "integer",
          "foreign_key": "pods.id"
        },
        {
          "name": "recommended_user_id",
          "data_type": "integer",
          "foreign_key": "users.id"
        },
        {
          "name": "created_at",
          "data_type": "timestamp",
          "default": "current_timestamp"
        }
      ],
      "relationships": [
        {
          "table": "pods",
          "foreign_key": "pod_id"
        },
        {
          "table": "users",
          "foreign_key": "recommended_user_id"
        }
      ]
    },
    {
      "table_name": "leave_approvals",
      "fields": [
        {
          "name": "id",
          "data_type": "integer",
          "primary_key": true
        },
        {
          "name": "leave_request_id",
          "data_type": "integer",
          "foreign_key": "leave_requests.id"
        },
        {
          "name": "approved_by",
          "data_type": "integer",
          "foreign_key": "users.id"
        },
        {
          "name": "approval_status",
          "data_type": "varchar(50)",
          "enum_values": [
            "approved",
            "rejected"
          ]
        },
        {
          "name": "comments",
          "data_type": "text"
        }
      ],
      "relationships": [
        {
          "table": "leave_requests",
          "foreign_key": "leave_request_id"
        },
        {
          "table": "users",
          "foreign_key": "approved_by"
        }
      ]
    },
    {
      "table_name": "dashboard_tiles",
      "fields": [
        {
          "name": "id",
          "data_type": "integer",
          "primary_key": true
        },
        {
          "name": "title",
          "data_type": "varchar(255)"
        },
        {
          "name": "content",
          "data_type": "text"
        },
        {
          "name": "type",
          "data_type": "varchar(50)",
          "enum_values": [
            "leave_summary",
            "pod_members"
          ]
        }
      ]
    }
  ]
}

## Business Logic

{
  "businessLogicComponents": [
    {
      "type": "Core Business Rules",
      "rules": [
        {
          "rule": "Leave Request Workflow",
          "description": "An employee can submit a leave request, which can be approved or rejected by a manager."
        },
        {
          "rule": "Pod Assignment",
          "description": "A manager can assign an employee to a specific pod."
        },
        {
          "rule": "Leave Balance Tracking",
          "description": "The system should track an employee's available leave balances."
        },
        {
          "rule": "Role-Based Access Control (RBAC)",
          "description": "Managers can access both manager and employee-related APIs, while employees can only access user-specific APIs."
        }
      ]
    },
    {
      "type": "Validation Requirements",
      "requirements": [
        {
          "requirement": "Authentication",
          "description": "The system should authenticate users using a token-based system."
        },
        {
          "requirement": "Authorization",
          "description": "The system should authorize users based on their roles (RBAC)."
        },
        {
          "requirement": "Data Validation",
          "description": "The system should validate user input data to prevent errors and security vulnerabilities."
        }
      ]
    },
    {
      "type": "Calculation or Processing Logic",
      "logic": [
        {
          "logic": "Leave Request Processing",
          "description": "The system should process leave requests, update leave balances, and notify employees and managers."
        },
        {
          "logic": "Pod Member Retrieval",
          "description": "The system should retrieve and display pod members and their roles."
        },
        {
          "logic": "Dashboard Data Aggregation",
          "description": "The system should aggregate data from multiple sources to display on the dashboard."
        }
      ]
    },
    {
      "type": "Workflow Steps",
      "steps": [
        {
          "step": "Leave Request Submission",
          "description": "An employee submits a leave request with category selection."
        },
        {
          "step": "Leave Request Approval/Rejection",
          "description": "A manager approves or rejects a leave request with comments."
        },
        {
          "step": "Pod Assignment",
          "description": "A manager assigns an employee to a specific pod."
        },
        {
          "step": "Pod Member Recommendation",
          "description": "An employee recommends colleagues for inclusion in a pod."
        }
      ]
    },
    {
      "type": "Integration Requirements",
      "requirements": [
        {
          "requirement": "API Integration",
          "description": "The system should integrate with multiple microservices using REST APIs and WebSockets."
        },
        {
          "requirement": "Database Integration",
          "description": "The system should interact with a PostgreSQL database using SQLAlchemy."
        },
        {
          "requirement": "Authentication Integration",
          "description": "The system should integrate with an authentication service using OAuth or JWT tokens."
        }
      ]
    }
  ]
}
